<?php
return  array(
 		'TMPL_FILE_DEPR'   => '.', //模板文件MODULE_NAME与ACTION_NAME之间的分割符
 		'WX_PATH' => './api/wx/', //微信文件夹目录
);