<?php
return  array(
 		'TMPL_FILE_DEPR'        => '.', //模板文件MODULE_NAME与ACTION_NAME之间的分割符
);

