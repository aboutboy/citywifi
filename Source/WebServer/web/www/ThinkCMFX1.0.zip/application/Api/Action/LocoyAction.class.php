<?php
namespace Api\Action;
use Common\Action\AdminbaseAction;
class LocoyAction extends AdminbaseAction{
	function index(){
		$this->display();
	}
}