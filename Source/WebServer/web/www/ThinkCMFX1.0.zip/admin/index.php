<?php
/**
 * 后台入口文件
 */
header("Location: ../index.php?g=admin");