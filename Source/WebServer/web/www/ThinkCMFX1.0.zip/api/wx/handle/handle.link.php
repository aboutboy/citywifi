<?php
include_once 'db.class.php';
//include_once 'tools.class.php';

global $postObj;

$db = new DB;
$db->open();
