<?php
$kuaidi = array(
		'key' => 'b7d9487380d14a0aafadf672c9080e7e',
		'url' => 'http://www.aikuaidi.cn/rest/',  //获取地址
);
$kuaidi['errorCode'] = include_once dirname(__FILE__).'/errorCode.php';
$kuaidi['statusCode'] = include_once dirname(__FILE__).'/statusCode.php';