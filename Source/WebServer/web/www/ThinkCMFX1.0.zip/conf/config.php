<?php
return array(
	//'配置项'=>'配置值'
		/* 自定义配置 */
		"UPLOADPATH"=>"data/upload/",
		'URL_CASE_INSENSITIVE'  => true, //url不区分大小写
		"URL_ROUTER_ON"=>true,
		'URL_ROUTE_RULES'=>array(),
);