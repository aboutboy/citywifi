<?php
//define('UC_CONNECT', 'mysql');
define('UC_CONNECT', '');
define('UC_DBHOST', 'localhost');
define('UC_DBUSER', 'root');
define('UC_DBPW', 'lhtworp');
define('UC_DBNAME', 'bbs@thinkcmf');
define('UC_DBCHARSET', 'utf8');
define('UC_DBTABLEPRE', '`bbs@thinkcmf`.pre_ucenter_');
define('UC_DBCONNECT', '0');
define('UC_KEY', '1111111111');
define('UC_API', 'http://bbs.thinkcmf.com/uc_server');
define('UC_CHARSET', 'utf-8');
define('UC_IP', '');
define('UC_APPID', '5');
define('UC_PPP', '20');


